Questions 1:
Given the following jumbled word, OBANWRI guess the correct English word.
A. RANIBOW
B. RAINBOW
C. BOWRANI
D. ROBWANI

Ans:- RAINBOW



Questions 2:
Write a program which prints “LETS UPGRADE”. (Please note that you have to
print in ALL CAPS as given

Ans:- code:- user_input = input("What do you want to print? ")
             print("Print this word ", user_input.upper())

      output:- What do you want to print? lets upgrade
               Print this word LETS UPGRADE



Questions 3:

ans:-

 code:-  def Profit(costPrice, sellingPrice) : 
  
       profit = (sellingPrice - costPrice) 
  
       return profit 
  
       def Loss(costPrice, sellingPrice) : 
  
       Loss = (costPrice - sellingPrice) 
    
       return Loss 
  
      if __name__ == "__main__" : 
  
      costPrice, sellingPrice = 15000, 20000
  
      if sellingPrice == costPrice : 
          print("No profit nor Loss") 
  
     elif sellingPrice > costPrice : 
          print(Profit(costPrice, sellingPrice), "Profit") 
  
     else : 
         print(Loss(costPrice, sellingPrice), "Loss") 
  

    output:- 5000 Profit



Questions 4:

  ans:-
  
 code:-
   Euros = float(input("Please enter Euros:"))
   rupees = Euros * 80
   print(rupees, " Rupees")



 output:-
     Please enter dollars: 50
     4000.0  Rupees
