Questions 1:
Create a numpy array starting from 2 till 50 with a stepsize of 3.

ans:-
      import numpy as np
      np.arange(start=2, stop=50, step=3)

output:-
array([2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35, 38, 41, 44, 47])



Questions 2:
Accept two lists of 5 elements each from the user.
Convert them to numpy arrays. Concatenate these arrays and print it. Also sort these arrays and print it.

ans:- 

    import numpy as np

    arr1 = np.array([3, 2, 0, 1])

    arr2 = np.array([5, 6, 7, 8])

    arr = np.concatenate((arr1, arr2))

    print(np.sort(arr))



Questions 3:
Write a code snippet to find the dimensions of a ndarray and its size.

ans:-
     import numpy as np
 
     arr = np.array( [[ 1, 2, 3], [ 4, 2, 5]] )
 
     print("Array is of type: ", type(arr))
 
     print("No. of dimensions: ", arr.ndim)
 
     print("Shape of array: ", arr.shape)
 
     print("Size of array: ", arr.size)
 



Questions 4:
How to convert a 1D array into a 2D array? Demonstrate with the help of a code snippet
Hint: np.newaxis, np.expand_dims

 ans:- 
      import numpy as np

      arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])

      newarr = arr.reshape(4, 3)

      print(newarr)



Questions 5:
Consider two square numpy arrays. Stack them vertically and horizontally.
Hint: Use vstack(), hstack()

 ans:-
       ## Horitzontal Stack
          import numpy as np
          f = np.array([1,2,3])
          g = np.array([4,5,6])

          print('Horizontal Append:', np.hstack((f, g)))

        Output:  Horizontal Append: [1 2 3 4 5 6]

       ## Vertical Stack
          import numpy as np
          f = np.array([1,2,3])
          g = np.array([4,5,6])

          print('Vertical Append:', np.vstack((f, g)))

          Output:  Vertical Append: [[1 2 3] [4 5 6]]
      

Questions 6:
How to get unique items and counts of unique items?

 ans:- 

 code:- my_list = [10, 20, 30, 40, 20, 50, 60, 40]
        print("Original List : ",my_list)
        my_set = set(my_list)
        my_new_list = list(my_set)
        print("List of unique numbers : ",my_new_list)


 output:-  Original List :  [10, 20, 30, 40, 20, 50, 60, 40]                                                             
           List of unique numbers :  [40, 10, 50, 20, 60, 30]

























