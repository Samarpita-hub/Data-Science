Questions 1:
Create an empty list. Accept 10 numbers from the user and append to it the list if it is an even number.

ans:-
     NumList = []

   Number = int(input("Please enter the Total Number of List Elements: "))
   for i in range(1, Number + 1):
      value = int(input("Please enter the Value of %d Element : " %i))
      NumList.append(value)

   print("\nEven Numbers in this List are : ")
   for j in range(Number):
     if(NumList[j] % 2 == 0):
        print(NumList[j], end = '   ')



Questions 2:
Create a notebook on LIST COMPREHENSION. This exercise is to put you in a Self learning mode.

ans:- 
    code:- # Map
           numbers = [1, 2, 3, 4, 5]
           squares = list(map(lambda x: x**2, numbers))
           print(squares)

           # List Comprehension
           numbers = [1, 2, 3, 4, 5]
           squares = [number**2 for number in numbers]
           print(squares)

   output:-
          [1, 4, 9, 16, 25]
          [1, 4, 9, 16, 25]



Questions 3:

You have seen in the videos how powerful dictionary data structure is.
In this assignment, given a number n, you have to write a program that generates a dictionary d which
contains (i, i*i), where i is from 1 to n (both included).
Then you have to just print this dictionary d.

ans:-    
    code:-
         n=int(input("Input a number "))
         d = dict()

         for x in range(1,n+1):
            d[x]=x*x
         print(d) 
    
   output:-
          10                                                                                                            
         {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}  




Questions 4:
There is a robot which wants to go the charging point to charge itself.
The robot moves in a 2-D plane from the original point (0,0). The robot can
move toward UP, DOWN, LEFT and RIGHT with given steps

ans:-    

code:-

import math
#Init vars
pos=[0,0]
moves={"UP":[0,1],
       "DOWN":[0,-1],
       "LEFT":[-1,0],
       "RIGHT":[1,0]}

#Set inputs
data=["UP 5",
    "DOWN 3",
    "LEFT 3",
    "RIGHT 2"]

#Move robot on valid moves
for inp in data:
    parts=inp.split()    
    mv=parts[0]
    val=parts[1]
    if mv in moves and val.isnumeric():
        pos[0] += moves[mv][0]*int(val)
        pos[1] += moves[mv][1]*int(val)

#get distance     
distance=math.sqrt(pos[0]**2 + pos[1]**2)
print(distance, "from [0,0] to",pos)



output:-
        
        2.23606797749979 from [0,0] to [-1, 2]










