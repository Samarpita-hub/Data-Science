Questions 1:
How to import pandas and check the version?

Ans:-
     > Pandas is one of the most important packages for data analysis in Python and that means frequent updates of the version of the Pandas. This leads to compatibility          issues with other dependencies of Pandas. Let’s discuss the ways to check the version of the Pandas and its dependencies running on any system.

   >  Find the version of the Pandas running on any system.
      We can use pd.__version__ to check the version of the Pandas running on any system.
     # importing pandas as pd 
       import pandas as pd 
  
     # Check the version 
       print(pd.__version__) 

  > Find the version of the dependencies for the given version of the Pandas running on any system.
    We can use the utility function pd.show_versions() to check the version of the dependencies.
    # importing pandas as pd 
      import pandas as pd 
  
    # Check the version of the dependencies 
      pd.show_versions() 


Questions 2:
How to create a series from a numpy array?

Ans:-
     # importing the modules 
       import numpy as np 
       import pandas as pd 
  
    # creating an NumPy array 
      array = np.array([10, 20, 1, 2, 3, 4, 5, 6, 7]) 
  
    # displaying the NumPy array 
      print("Numpy array is :") 
      display(array) 
  
    # converting the NumPy array  
    # to a Pandas series 
      series = pd.Series(array)  
  
    # displaying the Pandas series 
      print("Pandas Series : ") 
      display(series) 


Questions 3:
How to convert the index of a series into a column of a dataframe?

Ans:- 
         import pandas as pd

        data = {'Product': ['Computer','Printer','Monitor','Desk','Phone'],'Price': [1200,250,400,700,350] }
       
        df = pd.DataFrame(data, columns = ['Product','Price'], index = ['Item_1','Item_2','Item_3','Item_4','Item_5'])

        df.reset_index(inplace=True)
 
        print(df) 




Questions 4:
Write the code to list all the datasets available in seaborn library.
Load the 'mpg' dataset
Note: mpg dataset will be read from seaborn module in the manner sir has already shown(provided in the
materials folder)
   

Ans:- # Import seaborn
        import seaborn as sns

      # Apply the default theme
        sns.set_theme()

      # Load an example dataset
        tips = sns.load_dataset("tips")

      # Create a visualization
        sns.relplot(
            data=tips,
            x="total_bill", y="tip", col="time",
            hue="smoker", style="smoker", size="size",
        )



Questions 5:
Which country origin cars are a part of this dataset?


ans:-
     import pandas as pd 
     import numpy as np
     import seaborn as sns #visualisation
     import matplotlib.pyplot as plt #visualisation
     %matplotlib inline 
     sns.set(color_codes=True)

    # Loading the CSV file into a pandas dataframe.
    df = pd.read_csv(“CARS.csv”)
    df.head(5)

   # Removing irrelevant features
   df = df.drop([‘Model’,’DriveTrain’,’Invoice’, ‘Origin’, ‘Type’], axis=1)
   df.head(5)



Questions 6:
Extract the part of the dataframe which contains cars belonging to 'usa'

Ans:-
     # Import cars data
       import pandas as pd
       cars = pd.read_csv('cars.csv', index_col = 0)

     # Extract drives_right column as Series: dr
       dr = cars['drives_right']

     # Use dr to subset cars: sel
       sel = cars[dr]

     # Print sel
       print(sel)
     






















